﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    using System.Linq.Expressions;

    class Program
    {
        static void Main(string[] args)
        {
            var member = new MemberService();
            string id = "AA", pwd = "xxx";

            try
            {
                id = null;
                member.LoginA(id, pwd);
                //int result = member.LoginC(id, pwd);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            int result = member.LoginC(id, pwd);
            if (result == 0)
            {
                //..
            }else if (result == 1)
            {
                //...
            }
            else
            {
                //...
            }


            member.DoAdd(1, 2);

            //member.Load(-999);
        }
    }

    class Member
    {
    }

    class MemberService
    {
        //public Member Load(int memberId)
        //{
        //}

        public void LoginA(string id, string pwd)
        {
            //若失敗, 丟出Exception
            //......
            if (string.IsNullOrEmpty(id))
            {
                throw new Exception("帳號必需輸入");
            }
            throw new Exception("帳號或密碼有誤");
        }

        public bool LoginB(string id, string pwd)
        {
            //若失敗, 傳回false
            return true;
        }

        public int LoginC(string id, string pwd)
        {
            //1表示成功, 0表示密碼錯, 2表示已停權
            return 1;
        }

        public int DoAdd(int a, int b)
        {
            return a + b;
        }

    }

}
