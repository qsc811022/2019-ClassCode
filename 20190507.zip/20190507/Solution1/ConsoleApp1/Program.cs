﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    using System.Collections;
    using System.Security.Cryptography;

    class Program
    {
        static void Main(string[] args)
        {
            var arr=new ArrayList();
            arr.Add(111);
            arr.Add("aaaa");
            
            arr.Add(DateTime.Now);

            DoA(arr);
        }

        static void DoA(ArrayList arr)
        {
            int value = (int)arr[1];
        }

    }
}
