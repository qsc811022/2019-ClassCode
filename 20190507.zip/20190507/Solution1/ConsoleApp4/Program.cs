﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    using ClassLibrary1;

    class Program
    {
        static void Main(string[] args)
        {
            var order = new Order();

            string setting = "ClassLibrary1.Order,ClassLibrary1";

            string[] arr = setting.Split(',');
            string className = arr[0];
            string dllName = arr[1];

            var order2 = (Order)System.Reflection.Assembly
                                    .Load(dllName)
                                    .CreateInstance(className);


            int result = order2.DoAdd(1, 10);

            Console.WriteLine(result);
        }
    }
}
