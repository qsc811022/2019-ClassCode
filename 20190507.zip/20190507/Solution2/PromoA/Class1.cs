﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromoA
{
    using MyInterface;

    public class OrderA:IPromo
    {
        public int CalcTotal(int price)
        {
            return (price > 10000) ? price - 1000 : price;
        }
    }
}
