﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    using System.Reflection;
    using System.Threading;

    using MyInterface;

    using PromoA;

    class Program
    {
        static void Main(string[] args)
        {
            int price = 30000;

            //IPromo service =new Order();
            //IPromo service = new OrderA();
            IPromo service = GetObject();

            var total = service.CalcTotal(price);

            Console.WriteLine(total);
        }

        static IPromo GetObject()
        {
            string setting = System.Configuration.ConfigurationManager
                                .AppSettings["promo"].ToString();
            string[] arr = setting.Split(',');
            string className = arr[0];
            string dllName = arr[1];

            IPromo result = (IPromo)Assembly.Load(dllName).CreateInstance(className);
            return result;
        }
    }

    class Order:IPromo
    {
        public int CalcTotal(int price)
        {
            return price / 2; //5折
        }
    }
}
