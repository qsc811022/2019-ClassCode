﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            //int a = 99;
            string a = "ABCD";
            //Member a=new Member();

            foreach (var item in a)
            {
                
            }
        }
    }

    class Member
    {
    }
}
