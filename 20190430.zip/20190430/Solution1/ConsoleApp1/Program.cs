﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    using System.Dynamic;

    class Program
    {
        static void Main(string[] args)
        {
            VIP3 obj=new VIP3();

            IMember obj3 = obj as IMember;
            IMember obj4 = (IMember)obj;


            IMember obj2=new VIP3();
            
        }
    }

    class Member
    {
        
    }
    
        //介面
    interface IMember
    {
        string Address { get; set; } // property

        void DoA(); // method

        int DoAdd(int a, int b);
    }

    // 如果同時要繼承父類別且實作某介面, 父類別一定要寫在第一個
    class VIP4 : Member, IMember
    {
        public string Address { get; set; }

        public void DoA()
        {
            throw new NotImplementedException();
        }

        public int DoAdd(int a, int b)
        {
            throw new NotImplementedException();
        }
    }

    // 實作 IMember 介面
    class VIP3 : IMember
    {
        public string Address { get; set; }

        public void DoA()
        {
            throw new NotImplementedException();
        }

        public void DoB()
        {
        }

        public int DoAdd(int a, int b)
        {
            throw new NotImplementedException();
        }
    }

    // 繼承 Member 類別
    class VIP2 : Member
    {
    }

    class VIP
    {
    }


}
