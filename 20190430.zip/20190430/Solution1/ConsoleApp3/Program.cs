﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {222,1,77,33,99,22,5,1111 };

            var qry = arr.Where(item => item > 50).OrderBy(item=>item);

            //foreach (var item in arr)
            //{
            //    if (item > 50)
            //        Console.WriteLine(item);
            //}
            //var qry = arr.OrderBy(item => item);

            foreach (var item in qry)
            {
                Console.WriteLine(item);
            }
        }
    }
}
