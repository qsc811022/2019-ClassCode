﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            IA obj = new C();
            obj.DoC();
            IB obj2 = new C();
            obj2.DoC();
            C obj3 = new C();
            ((IA)obj3).DoC();
            ((IB)obj3).DoC();
        }
    }

    interface IA
    {
        void DoA();

        void DoC();
    }

    interface IB
    {
        void DoB();
        void DoC();
    }

    class C : IA, IB
    {
        public void DoA()
        {
            throw new NotImplementedException();
        }

        public void DoB()
        {
            throw new NotImplementedException();
        }
        
        void IA.DoC()
        {
            throw new NotImplementedException();
        }
        void IB.DoC()
        {
            throw new NotImplementedException();
        }
    }
}
