﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    using System.Collections;

    class Program
    {
        static void Main(string[] args)
        {
            var items = new List<int>();

            items.Add(5);
            items.Add(39);
            items.Add(41);
            items.Insert(0, 888);

            items.RemoveAt(0);
            items.Remove(39);

            items.Clear();

            foreach (var item in items)
            {
                Console.WriteLine(item);
            }

            int[] arr = { 1, 2, 3 };
            //((IList)arr).Add(5);

        }
    }
}
