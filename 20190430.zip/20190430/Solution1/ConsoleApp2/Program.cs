﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    using System.Collections;

    class Program
    {
        static void Main(string[] args)
        {
            //int[] arr = {1,77,33,99,22,5 };

            // string[] arr = {"a","z","c","m" };

            //DateTime[] arr =
            //    {
            //        new DateTime(1970,1,1),
            //        new DateTime(1960,1,1),
            //        new DateTime(1980,1,1),
            //    };

            Member[] arr =
                {
                    new Member{Name = "A1",Height=180, dtBirth = new DateTime(1970,1,1)},
                    new Member{Name = "A2",Height=170, dtBirth = new DateTime(1960,1,1)},
                    new Member{Name = "A3",Height=160, dtBirth = new DateTime(1980,1,1)},
                };

            IComparer sorter = new SortbyHeight();
            sorter = new SortbyHeightDESC();

            Array.Sort(arr, sorter);

            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
        }
    }

    class SortbyHeight : IComparer
    {
        public int Compare(object x, object y)
        {
            Member x1 = x as Member;
            Member y1 = y as Member;

            return x1.Height.CompareTo(y1.Height);   
        }
    }
    class SortbyHeightDESC : IComparer
    {
        public int Compare(object x, object y)
        {
            Member x1 = x as Member;
            Member y1 = y as Member;

            return y1.Height.CompareTo(x1.Height);
        }
    }


    class Member //:IComparable
    {
        public string Name { get; set; }

        public int Height { get; set; }

        public DateTime dtBirth { get; set; }

        public override string ToString()
        {
            return $"Name={Name}, Height={Height},Birthday={dtBirth:yyyy}";

            //return string.Format("Name={0}, Height={1},Birthday={2:yyyy}", this.Name, this.Height, this.dtBirth);

            //return "Name=" + Name + ", Height=" + Height + ",Birthday=" + dtBirth.Year;
        }

        public int CompareTo(object obj)
        {
            Member x = this;
            Member y = obj as Member;

            //return x.Height.CompareTo(y.Height);
            return y.Height.CompareTo(x.Height);

            //if (x.dtBirth < y.dtBirth)
            //    return -999;
            //else if (x.dtBirth == y.dtBirth)
            //    return 0;
            //else
            //{
            //    return 111;
            //}

            //if (x.Height < y.Height)
            //    return -999;
            //else if (x.Height == y.Height)
            //    return 0;
            //else
            //{
            //    return 111;
            //}

        }
    }
}
