﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Allen Kuo => firstName(名)=Allen, lastName(姓)=Kuo
            // Kuo, Allen => firstName(名)=Allen, lastName(姓)=Kuo

            string fullName, firstName, lastName;
            fullName = "Simon Wang";
            //fullName = "Wang2, Simon2";

            Member result = MemberFactory.GetObject(fullName);

            Console.WriteLine($"名={result.FirstName},姓={result.LastName}");
        }
    }

    class MemberFactory
    {
        public static Member GetObject(string fullName)
        {
            if (fullName.IndexOf(',') >= 0)
            {
                return new MemberB(fullName);
            }
            else
            {
                return new MemberA(fullName);
            }
        }
    }

    class MemberA : Member // Allen Kuo
    {
        public MemberA(string fullName)
        {
            var arr = fullName.Split(' ');
            this.FirstName = arr[0];
            this.LastName = arr[1];
        }
    }

    class MemberB : Member // Kuo,Allen
    {
        public MemberB(string fullName)
        {
            var arr = fullName.Split(',');
            this.FirstName = arr[1];
            this.LastName = arr[0];
        }
    }


    class Member
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }
    }
}
