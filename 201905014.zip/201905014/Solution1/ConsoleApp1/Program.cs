﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Allen Kuo => firstName(名)=Allen, lastName(姓)=Kuo
            // Kuo, Allen => firstName(名)=Allen, lastName(姓)=Kuo

            string fullName, firstName, lastName;
            //fullName = "Allen Kuo";
            fullName = "Kuo,Allen";

            string[] arr;

            if (fullName.IndexOf(',') >= 0)
            {
                arr = fullName.Split(',');
                firstName = arr[1];
                lastName = arr[0];
            }
            else
            {
                arr = fullName.Split(' ');
                firstName = arr[0];
                lastName = arr[1];
            }

            Console.WriteLine($"名={firstName}, 姓={lastName}");
        }
    }
}
