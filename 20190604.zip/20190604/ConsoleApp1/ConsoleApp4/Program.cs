﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
	class Program
	{
		static void Main(string[] args)
		{
			int d =DateTime.Today.Day;
			int m = DateTime.Today.Month;
			Console.WriteLine(m);


			if (d > 10 && m>2)
			{

			}

			string s = null;
			//s.Length;
			if (s == null || s.Length > 5)
			//if (s.Length > 5 || s == null)
				{
				Console.WriteLine("A");
			}
		}
	}
}
