﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			int price = 30000;
			int total;

			//var obj=new Order();
			//total = obj.GetTotal(price, 88);

			IPromo promo = new PromoA();

			//promo = new PromoB();

			Order order = new Order(promo);
			total = order.CalcTotal(price);

			Console.WriteLine(total);

			
		}
	}

	/// <summary>
	/// 滿萬送千
	/// </summary>
	public class PromoB : IPromo
	{
		public int GetTotal(int price)
		{
			return (price >= 10000) ? price - 1000 : price;
		}
	}

	public class PromoA : IPromo
	{
		public int GetTotal(int price)
		{
			return price / 2;
		}
	}

	public interface IPromo
	{
		int GetTotal(int price); // 計算優惠價
	}

	class Order
	{
		private IPromo promo;
		public Order(IPromo promo)
		{
			this.promo = promo;
		}

		public int CalcTotal(int price)
		{
			return promo.GetTotal(price);
		}
		//public int GetTotal(int price, int discount)
		//{
		//	//return price / 2; //五折
		//	return price * discount / 100; // 8折
		//}

	}

}
