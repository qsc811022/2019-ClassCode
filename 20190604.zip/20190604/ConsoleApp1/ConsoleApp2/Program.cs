﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
	class Program
	{
		static void Main(string[] args)
		{
			int a;  // 0

			int b;
			b = 5;

			int c = 6;

			bool b2; //false

			//int d = null;

			int? f = null;
			Nullable<int> f2 = null;

			//Nullable<string> f3;

			string f4 = null;

		}
	}
}
